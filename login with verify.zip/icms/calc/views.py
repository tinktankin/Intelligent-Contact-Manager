from django.shortcuts import render,redirect
from django.contrib.auth.models import User,auth
from django.contrib import messages
from django.core.mail import EmailMessage,send_mail
from random import randint

def random_with_N_digits(n):
    range_start = 10**(n-1)
    range_end = (10**n)-1
    return randint(range_start, range_end)
messag=str(random_with_N_digits(4))
def home(request):
	if request.method=="POST":
		username=request.POST['username']
		#phonenumber=request.POST['phonenumber']
		email=request.POST['email']
		password=request.POST['password']
		password1=request.POST['password1']
		if password==password1:
			if User.objects.filter(username=username).exists():
				messages.info(request,'Username already exists')
				return redirect('home')
			elif User.objects.filter(email=email).exists():
				messages.info(request,"email already exists")
				return redirect('home')
			else:
				user=User.objects.create_user(username=username, email=email, password=password)
				user.is_active=False
				email_subject='activate'
				email_body=messag
				send_mail(
					email_subject,
					email_body,
					'saichaitanyasahini@gmail.com',
					[email],
					fail_silently=False
					)
				user.save();
				return redirect('verify')
		else:
			messages.info(request,'password not matching')
			return redirect('home')
	else:
		return render(request,'home.html')
def login(request):
	if request.method=="POST":
		email=request.POST['email']
		password=request.POST['password']

		user = auth.authenticate(email=email, password=password)
		if user is not None:
			auth.login(request, user)
			return redirect('login')
		else:
			messages.info(request,"invalid user please retry or signup")
			return redirect('home')
	else:
		return render(request,'login.html')

def verify(request):
	if request.method=="POST":
		verify=request.POST['verify']
		if messag==verify:
			messages.info(request,'user created')
			return redirect('login')
		else:
			messages.info(request,'Invalid verification code')
			return redirect('home')
	else:
		return render(request,'verify.html')